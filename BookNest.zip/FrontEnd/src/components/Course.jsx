import React from 'react'

const Course = () => {

  return (
    <>
      <div className='max-w-screen-2xl container mx-auto md:px-20 px-4'>
        <div className=''>
        <h1 className='text-4xl font-semibold  md:text-4xl'> We'r Delighted To Have You 
          <span className='text-pink-500'>Here! :)</span> </h1>
          </div>
      </div>
    </>
  )
}

export default Course
